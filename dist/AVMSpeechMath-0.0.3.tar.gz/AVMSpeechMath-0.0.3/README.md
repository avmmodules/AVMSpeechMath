# AVMSpeechMath
Perform voice operations in Spanish with Python.